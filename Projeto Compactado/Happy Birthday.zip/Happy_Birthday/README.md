# Happy Birthday <img src="\icon for readme\android-svgrepo-com__1_-removebg-preview.png" width="50" height="auto"></img>

### Curso: Noções básicas do Android com Compose

- <b>Exercício:</b> Criar um cartão de aniversário com o Android Studio.

 - 🚨 Apesar de ter commits de vários usuários, fui eu (<a href="https://github.com/stxrkwas">@stxrkwas</a>) quem fez, os commits com outras contas foram enganos.  
